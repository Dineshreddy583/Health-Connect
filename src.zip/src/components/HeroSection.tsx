import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Clock, Heart } from "lucide-react";
import heroImage from "@/assets/hero-medical.jpg";

const HeroSection = () => {
  return (
    <section className="min-h-screen bg-gradient-to-br from-medical-background via-background to-accent/20 flex items-center">
      <div className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="animate-fade-in">
            <div className="flex items-center gap-2 mb-6">
              <Heart className="h-8 w-8 text-medical-success" />
              <span className="text-sm font-medium text-muted-foreground tracking-wide uppercase">
                Trusted Healthcare Platform
              </span>
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Healthcare
              <span className="bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
                {" "}at Home
              </span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed max-w-lg">
              Connect with licensed doctors instantly. Get prescriptions, consultations, 
              and health monitoring—all from the comfort of your home.
            </p>
            
            {/* Trust Indicators */}
            <div className="flex flex-wrap gap-6 mb-10">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-medical-success" />
                <span className="text-sm font-medium">HIPAA Compliant</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-medical-success" />
                <span className="text-sm font-medium">24/7 Available</span>
              </div>
              <div className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-medical-success" />
                <span className="text-sm font-medium">Licensed Doctors</span>
              </div>
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="medical" size="lg" className="group">
                Find a Doctor
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button variant="medical-outline" size="lg">
                Learn More
              </Button>
            </div>
          </div>
          
          {/* Hero Image */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-medical-success/20 rounded-3xl blur-2xl"></div>
            <img 
              src={heroImage} 
              alt="Doctor consultation via video call"
              className="relative w-full h-auto rounded-3xl shadow-2xl object-cover"
            />
            
            {/* Floating Stats */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl p-6 shadow-lg animate-pulse-glow">
              <div className="text-3xl font-bold text-primary">500K+</div>
              <div className="text-sm text-muted-foreground">Happy Patients</div>
            </div>
            
            <div className="absolute -top-6 -right-6 bg-white rounded-2xl p-6 shadow-lg">
              <div className="text-3xl font-bold text-medical-success">98%</div>
              <div className="text-sm text-muted-foreground">Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;