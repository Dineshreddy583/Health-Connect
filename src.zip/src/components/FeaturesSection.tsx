import { Card } from "@/components/ui/card";
import { 
  Video, 
  Calendar, 
  Pill, 
  FileText, 
  MessageSquare, 
  Shield,
  Clock,
  Users,
  Heart
} from "lucide-react";

const features = [
  {
    icon: Video,
    title: "Video Consultations",
    description: "High-quality video calls with licensed doctors, including screen sharing and digital tools for better diagnosis.",
    color: "text-primary"
  },
  {
    icon: Calendar,
    title: "Easy Scheduling", 
    description: "Book appointments instantly or schedule for later. Automated reminders ensure you never miss a consultation.",
    color: "text-medical-success"
  },
  {
    icon: Pill,
    title: "Prescription Management",
    description: "Digital prescriptions sent directly to your pharmacy. Track refills and manage all your medications in one place.",
    color: "text-medical-warning"
  },
  {
    icon: FileText,
    title: "Health Records",
    description: "Secure storage of all your medical records, test results, and vaccination history accessible anytime.",
    color: "text-medical-info"
  },
  {
    icon: MessageSquare,
    title: "Secure Messaging",
    description: "HIPAA-compliant messaging with your healthcare team. Get quick answers between appointments.",
    color: "text-primary"
  },
  {
    icon: Users,
    title: "Family Care",
    description: "Manage healthcare for your entire family from one account. Perfect for parents and caregivers.",
    color: "text-medical-success"
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-24 bg-gradient-to-b from-background to-medical-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Shield className="h-6 w-6 text-primary" />
            <span className="text-sm font-medium text-muted-foreground tracking-wide uppercase">
              Comprehensive Care
            </span>
          </div>
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Everything You Need for
            <span className="bg-gradient-to-r from-primary to-medical-success bg-clip-text text-transparent">
              {" "}Better Health
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our platform provides all the tools and services you need for complete healthcare management,
            from initial consultation to ongoing care.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card 
                key={index} 
                className="p-8 hover:shadow-medical transition-all duration-300 group cursor-pointer border-0 bg-white/60 backdrop-blur-sm"
              >
                <div className="mb-6">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-background flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                    <IconComponent className={`h-7 w-7 ${feature.color}`} />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </Card>
            );
          })}
        </div>

        {/* Trust Section */}
        <div className="mt-20 text-center">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
            <div className="flex flex-col items-center">
              <Clock className="h-8 w-8 text-primary mb-2" />
              <div className="text-2xl font-bold text-foreground">24/7</div>
              <div className="text-sm text-muted-foreground">Available</div>
            </div>
            <div className="flex flex-col items-center">
              <Shield className="h-8 w-8 text-medical-success mb-2" />
              <div className="text-2xl font-bold text-foreground">100%</div>
              <div className="text-sm text-muted-foreground">Secure</div>
            </div>
            <div className="flex flex-col items-center">
              <Users className="h-8 w-8 text-medical-warning mb-2" />
              <div className="text-2xl font-bold text-foreground">1000+</div>
              <div className="text-sm text-muted-foreground">Doctors</div>
            </div>
            <div className="flex flex-col items-center">
              <Heart className="h-8 w-8 text-medical-info mb-2" />
              <div className="text-2xl font-bold text-foreground">5M+</div>
              <div className="text-sm text-muted-foreground">Consultations</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;